# Notary
Notary: A coding project for searching through text in javascript
